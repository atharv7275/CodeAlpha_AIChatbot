/**
 * 
 */
/**
 * 
 */
module SimpleChatBot {
	requires java.desktop;
}