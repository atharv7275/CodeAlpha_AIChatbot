package ChatBot;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SimpleChatBot extends JFrame {

    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;

    public SimpleChatBot() {
        setTitle("AI Chatbot");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Chat area
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("Arial", Font.PLAIN, 16));
        add(new JScrollPane(chatArea), BorderLayout.CENTER);

        // Input area
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        sendButton = new JButton("Send");

        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        add(inputPanel, BorderLayout.SOUTH);

        // Action for sending messages
        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());
    }

    private void sendMessage() {
        String userInput = inputField.getText().trim().toLowerCase();
        if (userInput.isEmpty()) return;

        chatArea.append("You: " + userInput + "\n");

        String response = getResponse(userInput);
        chatArea.append("Bot: " + response + "\n\n");

        inputField.setText("");
    }

    // Smart keyword-based response logic
    private String getResponse(String input) {
        if (input.contains("hi") || input.contains("hello") || input.contains("hey")) {
            return "Hello! How can I help you?";
        } else if (input.contains("how are you")) {
            return "I'm just a bot, but I'm doing great!";
        } else if (input.contains("your name") || input.contains("who are you")) {
            return "I am a Java AI Chatbot.";
        } else if (input.contains("bye") || input.contains("goodbye") || input.contains("see you")) {
            return "Goodbye! Have a nice day!";
        } else if (input.contains("time")) {
            return "Sorry, I cannot tell the time yet.";
        } else if (input.contains("help")) {
            return "I can respond to greetings, tell my name, and say goodbye!";
        } else {
            return "Sorry, I don't understand that.";
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SimpleChatBot().setVisible(true));
    }
}
